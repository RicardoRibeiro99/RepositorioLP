package TrabalhoLP;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		BinaryTree bt = new BinaryTree();
		bt.insert(1);
		bt.insert(2);
		bt.insert(3);
		bt.delete(2);
		
		hanoiTower ht = new hanoiTower();
		ht.add(1);
		ht.add(2);
		ht.add(3);
		ht.peak();
		ht.remove();
		ht.peak();
		
		bt.listarDecrescente();
		
		while(bt.isEmpty()!=true) {
			ht.add(maxvalue(bt));
		}
	}

}


