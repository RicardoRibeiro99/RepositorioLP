package TrabalhoLP;

public class BinaryTree {
	
	private Node root;
	
	public boolean isEmpty() {
		return (this.root == null);
	}
	
	public Node getRoot() {
		return this.root;
	}
	
	public void insert(int value) {
		System.out.println("[input: " + value + "]");
		if(root == null) {
			this.root = new Node(value);
			System.out.println("-> inserted: " + value);
			return;
		}
		insertNode(this.root, value);
		System.out.println("-> inserted: " + value);
		return;
	}
	
	private Node insertNode(Node root, int value) {
		Node tmpNode = null;
		System.out.println(" -> " + root.getValue());
		if(root.getValue() >= value) {
			System.out.println("[Left]");
				if(root.getLeft() == null) {
					root.setLeft(new Node(value));
				}else {
					tmpNode = root.getLeft();
				}
		}else {
			System.out.println("[Right]");
			if(root.getRight() == null) {
				root.setRight(new Node(value));
			}else {
				tmpNode = root.getRight();
			}
		}
		return insertNode(tmpNode, value);
	}
	
	public void delete(int value) {
		deleteNode(this.root , value);
	}
	
	private Node deleteNode(Node root, int value) {
		if(root == null) {
			return root;
		}
		
		if(value < root.getValue()) {
			root.setLeft(deleteNode(root.getLeft(), value));
		}else if(value > root.getValue()){
			root.setRight(deleteNode(root.getRight(), value));
		}else {
			if(root.getLeft() == null) {
				System.out.println("Deleting" + value);
				return root.getRight();
			}else if(root.getRight() ==  null) {
				System.out.println("Deleting" + value);
				return root.getLeft();
			}else {
				int minValue = minValue(root.getRight());
				root.setValue(minValue);
				root.setRight(deleteNode(root.getRight(), minValue));
				System.out.println("Deleting" + value);
			}
		}
		
		return root;
	}
	
	private int minValue(Node node) {
		if(node.getLeft() != null) {
			return minValue(node.getLeft());
		}
		return node.getValue();
	}
	
	public int maxValue(Node node) {
		if(node.getRight()!=null) {
			return maxValue(node.getRight());
		}
		return node.getValue();
	}

	
	public void inOrderTraversal() {
		doInOrder(this.root);
	}
	
	private void doInOrder(Node root) {
		if(root == null) {
			return;
			}
		doInOrder(root.getLeft());
		System.out.println(root.getValue() + " ");
		doInOrder(root.getRight());
		}
	
	public void listarDecrescente() {
		listarDecrescente(this.root);
	}
	
	private void listarDecrescente(Node root) {
		if(root==null) {
			return;
		}
		listarDecrescente(root.getRight());
		System.out.println(root.getValue()+" ");
		listarDecrescente(root.getLeft());
	}
}
	
	

