package TrabalhoLP;

import javax.swing.*;

public class hanoiTower {
	
	int top;
	int bottom;
	int size;
	int amountOfElements;
	int ht[];
	
	public hanoiTower() {
		top = bottom = -1;
		size = 100;
		ht = new int[size];
		amountOfElements = 0;
	}
	
	public boolean isEmpty() {
		if(amountOfElements == 0) {
			return true;
			}
			return false;
		}
		
	public boolean isFull() {
		if(amountOfElements == size -1) {
			return true;
			}
			return false;
		}
	
		
	public void add(int e) {
		if(!isFull()) {
			if(top == -1) {
				top = 0;
			}
			bottom++;
			ht[bottom] = e;
			amountOfElements++;
			}
		}
	
	public void remove() {
		if(! isEmpty()) {
			bottom --;
			amountOfElements --;
			}
		}
	
	public void peak() {
		String elements = "";
		
			for(int i = bottom; i>=0; i--) {
				elements += ht[i] + " - ";
			}
		
		}
	}
	
