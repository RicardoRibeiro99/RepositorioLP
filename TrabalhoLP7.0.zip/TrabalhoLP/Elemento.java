package TrabalhoLP;

public class Elemento {
	
	
	//atributos
	protected int numero;

	//construtores
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	//metodos

}
