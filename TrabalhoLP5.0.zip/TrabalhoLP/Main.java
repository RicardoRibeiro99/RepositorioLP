package TrabalhoLP;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		int valor;
		
		BinaryTree bt = new BinaryTree();
		hanoiTower ht = new hanoiTower();
		
		while(bt.isEmpty()!=true) {
			int auxiliar = bt.maxValue(bt.getRoot());
			bt.delete(auxiliar);
			ht.add(auxiliar);
		}
		
		
		while(choice != 5) {
			System.out.println("________________________ Torres de Hanoi ________________________");
			System.out.println("");
			
			System.out.println("1 - Adicionar um valor � �rvore Bin�ria");
			System.out.println("2 - Adicionar o valor � Torre de Hanoi e remover da Arvore Bin�ria");
			System.out.println("3 - Apagar valor da �rvore Bin�ria");
			System.out.println("4 - Sair");
			
			System.out.println("\n Escolha a sua op��o: ");
			
			choice = scanner.nextInt();
			
			switch(choice) {
			case 1:
				System.out.println("\n Insira o valor que pretende adicionar:");
				valor=scanner.nextInt();
				bt.insert(valor);
				break;
				
			case 2:
				System.out.println("\n Insira o valor que pretende adicionar:");
				valor=scanner.nextInt();
				ht.add(valor);
				break;
				
			case 3:
				System.out.println("\n Insira o valor que pretende eliminar:");
				valor=scanner.nextInt();
				bt.delete(valor);
				break;
			case 4:
				break;
			}
			
		}
	}
}



