package TrabalhoLP;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		int valor;
		
		BinaryTree bt = new BinaryTree();
		hanoiTower ht = new hanoiTower();
		
		bt.insert(9);
		bt.insert(5);
		bt.insert(20);
		bt.insert(3);
		bt.insert(23);
		

		while(choice != 5) {
			System.out.println("________________________ Torres de Hanoi ________________________");
			System.out.println("");
			System.out.println("1 - Adicionar um valor � �rvore Bin�ria");
			System.out.println("2 - Construir a Torre de  Hanoi");
			System.out.println("3 - Apagar valor da �rvore Bin�ria");
			System.out.println("4 - Imprimir a �rvore Bin�ria");
			System.out.println("5 - Sair");
			
			System.out.println("\n Escolha a sua op��o: ");
			
			choice = scanner.nextInt();
			System.out.println(" ");
			
			switch(choice) {
			case 1:
				System.out.println("\n Insira o valor que pretende adicionar:");
				valor=scanner.nextInt();
				bt.insert(bt.getRoot(), valor);
				break;
				
			case 2:
				System.out.println("torre de hanoi: \n");
				while(bt.isEmpty()!= true) {
					int auxiliar = bt.minValue(bt.getRoot());
					System.out.println("-----------------");
					System.out.println("----- " + auxiliar + " -----");
					System.out.println("-----------------");
					ht.add(auxiliar);
					bt.delete(auxiliar);
				}

				break;
				
			case 3:
				System.out.println("\n Insira o valor que pretende eliminar:");
				valor=scanner.nextInt();
				bt.delete(valor);
				System.out.println("Apagou o valor: " + valor);
				break;
			case 4:
				System.out.println(bt.preOrder(bt.getRoot()));
				break;
			case 5:
				System.out.println("Obrigado e At� Breve");
				System.exit(0);
				break;
			}
			
		}
	}
}



