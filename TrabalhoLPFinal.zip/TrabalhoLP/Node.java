package TrabalhoLP;

public class Node {
	
	private int value;
	private Node left;
	private Node right;

	// Acessores 
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public Node getLeft() {
		return left;
	}
	public void setLeft(Node left) {
		this.left = left;
	}
	public Node getRight() {
		return right;
	}
	public void setRight(Node right) {
		this.right = right;
	}
	
	
	// Construtores
	public Node(int value) {
		this.value = value;
		this.left = null;
		this.right = null;
	}
	
	public int height()
	{
		return height(this);
	}
	
	public int height(Node root)
	{
		if(root == null) {
			return 0;
		}
		
		int eHeight = height(root.getLeft()); 
		
        int dHeight = height(root.getRight());
        
        return eHeight > dHeight ? eHeight + 1 : dHeight + 1;
	}
	
	// Override toString
	@Override
	public String toString() {
		return String.format("[%d , %s, %s ]\n",  this.value, this.left, this.right );
	}
	
	
	
	
}
