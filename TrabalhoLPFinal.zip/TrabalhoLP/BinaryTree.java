package TrabalhoLP;

public class BinaryTree {
	
	private Node root;
	
	static final int COUNT = 10; 
	
	public boolean isEmpty() {
		return (this.root == null);
		
	}
	
	public Node getRoot() {
		return this.root;
	}
	
	
	public void insert(int value) {
		root = insert(root, value);
	}
	
	
	public Node insert (Node root, int value) {
		if (root == null) {
			return new Node(value);
		}

		if (value < root.getValue()) {
			root.setLeft(insert(root.getLeft(), value));
		} else if (value > root.getValue()) {
			root.setRight(insert(root.getRight(), value));
		}

		return root;
	}
	
	public void delete(int value) {
		this.root = deleteNode(this.root , value);
	}
	
	private Node deleteNode(Node root, int value) {
		
		if(root == null) {
			return root;
		}
		
		if(value < root.getValue()) {
			root.setLeft(deleteNode(root.getLeft(), value));
			
		}else if(value > root.getValue()){
			root.setRight(deleteNode(root.getRight(), value));
			
		}else {
			if(root.getLeft() == null) {
				return root.getRight();
			}else if(root.getRight() ==  null) {
				return root.getLeft();
			}else {
				int minValue = minValue(root.getRight());
				root.setValue(minValue);
				root.setRight(deleteNode(root.getRight(), minValue)); 
			}
		}
		return root;
	}
	
	public int size() {
		return(size(root));
	}
	
	private int size(Node node) {
		if(node == null) {
			return(0);
		}else {
			return(size(node.getLeft()) + 1 + size(node.getRight()));
		}
	}
	
	public int minValue(Node node) {
		 if (node == null) 
		        return Integer.MAX_VALUE; 
		  
		    int res = node.getValue(); 
		    int lres = minValue(node.getLeft()); 
		    int rres = minValue(node.getRight()); 
		  
		    if (lres < res) 
		        res = lres; 
		    if (rres < res) 
		        res = rres; 
		    return res; 
		}
	
	public int maxValue(Node node) {
		  if (node == null) 
	            return Integer.MIN_VALUE; 
	  
	        int res = node.getValue(); 
	        int lres = maxValue(node.getLeft()); 
	        int rres = maxValue(node.getRight()); 
	  
	        if (lres > res) 
	            res = lres; 
	        if (rres > res) 
	            res = rres; 
	        return res; 
	    }
	
	public String toString() {
		return "Node [root=" + root + "]";
	}

	
	public void inOrderTraversal() {
		doInOrder(this.root);
	}
	
	private void doInOrder(Node root) {
		if(root == null) {
			return;
			}
		doInOrder(root.getLeft());
		System.out.println(root.getValue() + " ");
		doInOrder(root.getRight());
		}
	
	public void listarDecrescente() {
		listarDecrescente(this.root);
	}
	
	private void listarDecrescente(Node root) {
		if(root==null) {
			return;
		}
		listarDecrescente(root.getRight());
		System.out.println(root.getValue()+" ");
		listarDecrescente(root.getLeft());
	}
	
	public String preOrder(Node root) {
		String returned = "";

		if(root != null) {
			
			returned += root.getValue() + " ";	
		}
		
		if(root.getLeft() != null) {
			returned += preOrder(root.getLeft());
		}
		
		if(root.getRight() != null) {
			returned += preOrder(root.getRight());
		}
		
		return returned;

	}
}
	
	

